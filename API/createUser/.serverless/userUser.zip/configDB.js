const mongoose = require("mongoose");
const dotenv = require("dotenv");
dotenv.config();

const uri = process.env.DBURL;

// Here put the database you want to connect to.
mongoose.connect(uri, { useFindAndModify: false }, { useNewUrlParser: true });

var db = mongoose.connection;

db.on("error", () => console.log("Error in connection"));
db.once("open", () => {
  console.log("The mongodb is connected");
});

module.exports = db;
