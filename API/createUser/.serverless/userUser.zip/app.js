const db = require("./configDB");
const User = require("./model/User");

const createUser = async (event, context) => {
  let user = new User();
  const name = "silas";
  const email = "silas3@gmail.com";
  const phone = 4376885717;
  const address = "north york, toronto, canada";
  console.log("Hi check point1");

  User.findOne({ email }).then((userData) => {
    if (userData) {
      console.log("Email exist");
    }
  });

  try {
    user.name = name;
    user.email = email;
    user.phone = phone;
    user.address = address;
    const result = await user.save();

    if (result) {
      console.log(`Success`);
      return "Success!";
    }
  } catch (error) {
    return `Error ${error}`;
  }
};

// createUser();
module.exports = createUser();
