/**
 * User module - Ref: From mongoose docs https://goo.gl/szRMTi
 * @module User
 */

var mongoose = require("mongoose");
var Schema = mongoose.Schema;

let userSchema = new Schema(
  {
    name: String,
    email: {type:String , unique: true},
    phone: Number,
    address: String,
  },
  { timestamps: true, collection: "users" }
);

module.exports = mongoose.model("User", userSchema);
